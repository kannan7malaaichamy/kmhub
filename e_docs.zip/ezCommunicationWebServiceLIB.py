from __future__ import print_function
import fitz
import natsort

import calendar
from pdf2image import convert_from_path
import os
import moviepy.video.io.ImageSequenceClip
import moviepy.editor as mp
import pypandoc
import argparse
import docx2txt
from mhmovie.code import *
import requests
# create parser
from gtts import gTTS
from mailmerge import MailMerge
from datetime import date
from docx2pdf import convert
#from docx2html import convert as htmlcovert

from datetime import datetime
import os
import lxml.etree
from moviepy.editor import *
# xmlstr is your xml in a string
import time
# 1593586355.9822
from cloudinary.api import delete_resources_by_tag, resources_by_tag
from cloudinary.uploader import upload
from cloudinary.utils import cloudinary_url
from twilio.rest import Client
from subprocess import  Popen
import xmltodict


#parser = argparse.ArgumentParser()

#parser.add_argument("triggerFile")
#parser.add_argument("configFile")
#args = parser.parse_args()

#triggerFile = args.triggerFile

#configFile = args.configFile
# parse the arguments
#args = parser.parse_args()
#print(configFile)
#exit(1)

configdir = "D:/e_Docs_Runtime/config/"
configFile="D:/ezComms_Runtime/config/properties.xml"
LIBRE_OFFICE = r"C:/Program Files/LibreOffice/program/soffice.exe"
triggerFile=''
xmldir = ''
triggerdir=''
pdfoutdir = ''
htmloutdir = ""
digitaltemplatedir = ""
audiotemplatedir=""
videotemplatedir=""
htmloutdir = ""
audiooutdir = ""
videooutdir = ""
docxoutdirdigitalchannel = ""
docoutdir = ""
docxoutdir = ""
templatedir = ""
resourcedir = ""
pdfoutputflag = ""
wordoutputflag = ""
htmloutputflag = ""
videooutputflag = ""
dotDoc = ""
dotPdf = ""
dotDocx = ""
dotHtml = ""
dotxml = ""
templateExtn = ""
imageFileExtn = ""
errorPDFPath = ""
templateName=""
xmlFileNameTag = ""
audioExtn =""
videoExtn =""

def word2PDF(input_docx,out_folder,LIBRE_OFFICE):
    p = Popen([LIBRE_OFFICE, '--headless', '--convert-to', 'pdf', '--outdir',
               out_folder, input_docx])
    print([LIBRE_OFFICE, '--convert-to', 'pdf', input_docx])
    p.communicate()
    
def append_timestamp(filename):
    tm = time.strftime('%a%d%b%Y%H%M%S')
    filename_with_timestamp = filename + "_" + tm
    return (filename_with_timestamp)

print("Start Time ......" + append_timestamp("start"))

def dump_response(response):
    print("Upload response:")
    for key in sorted(response.keys()):
        print("  %s: %s" % (key, response[key]))


def sendMessage(urlinput, to_whatsapp_number, message):
    # client credentials are read from TWILIO_ACCOUNT_SID and AUTH_TOKEN
    client = Client()

    # this is the Twilio sandbox testing number
    from_whatsapp_number = 'whatsapp:+14155238886'
    # replace this number with your own WhatsApp Messaging number
    # to_whatsapp_number = 'whatsapp:+917708605798'

    client.messages.create(body=message,
                           from_=from_whatsapp_number,
                           to=to_whatsapp_number)

    message = client.messages \
        .create(
        media_url=urlinput,
        from_=from_whatsapp_number,
        to=to_whatsapp_number
    )


# xmldir pdfoutdir htmloutdir docdir docxdir templatedir configdir resourcedir pdfoutputflag wordoutputflag htmloutputflag videooutputflag
# dotDoc dotPdf dotDocx dotHtml templateExtn imageFileExtn errorPDFPath
def loadconfig():
    with open(configFile) as fdxml:
        properites  = xmltodict.parse(fdxml.read())
        xmldir  = properites['properties']['xmldir']
        triggerdir = properites['properties']['triggerdir']
        pdfoutdir = properites['properties']['pdfoutdir']
        htmloutdir = properites['properties']['htmloutdir']
        audiooutdir = properites['properties']['audiooutdir']
        videooutdir = properites['properties']['videooutdir']
        docoutdir = properites['properties']['docoutdir']
        docxoutdirdigitalchannel = properites['properties']['docxoutdirdigitalchannel']
        docxoutdirAudio = properites['properties']['docxoutdirAudio']
        docxoutdirVideo = properites['properties']['docxoutdirVideo']
        digitaltemplatedir = properites['properties']['digitaltemplatedir']
        audiotemplatedir = properites['properties']['audiotemplatedir']
        videotemplatedir = properites['properties']['videotemplatedir']
        configdir = properites['properties']['configdir']
        resourcedir = properites['properties']['resourcedir']
        pdfoutputflag = properites['properties']['pdfoutputflag']
        wordoutputflag = properites['properties']['wordoutputflag']
        htmloutputflag = properites['properties']['htmloutputflag']
        videooutputflag = properites['properties']['videooutputflag']
        dotDoc = properites['properties']['dotDoc']
        dotPdf = properites['properties']['dotPdf']
        dotDocx = properites['properties']['dotDocx']
        dotHtml = properites['properties']['dotHtml']
        dotxml= properites['properties']['dotxml']
        templateExtn = properites['properties']['templateExtn']
        processCompleteExtn = properites['properties']['processCompleteExtn']
        processErrorExtn = properites['properties']['processErrorExtn']
        imageFileExtn = properites['properties']['imageFileExtn']
        xmlFileNameTag = properites['properties']['xmlFileNameTag']
        audioExtn = properites['properties']['audioExtn']
        videoExtn = properites['properties']['videoExtn']
        errorPDFPath = properites['properties']['errorPDFPath']
        triggerFile=properites['properties']['triggerFile']
        xmlFileNameTag= properites['properties']['xmlFileNameTag']

    fdxml.close()
    print("inside - congig" , xmlFileNameTag + docxoutdirdigitalchannel)
    return properites

#exit(1)
def executeMappingRule(document,doc,templateID):
    if templateID == "RB_CLM_LetterTemplate_6798":
        document.merge(addressLine3=doc['correspondence']['addressLine3'],fullName=doc['correspondence']['fullName'],expiryDate=doc['correspondence']['expiryDate'],addressLine1=doc['correspondence']['addressLine1'],addressLine4=doc['correspondence']['addressLine4'],balanceAmount=doc['correspondence']['balanceAmount'],accountNumber=doc['correspondence']['accountNumber'],balanceDate=doc['correspondence']['balanceDate'],shortName=doc['correspondence']['shortName'],currentDate=doc['correspondence']['currentDate'],addressLine5=doc['correspondence']['addressLine5'],operatorName=doc['correspondence']['operatorName'],addressLine2=doc['correspondence']['addressLine2'])
    elif templateID == "tcs_retirement_letter_template_9867":
        document.merge(PSamount=doc['correspondence']['PSamount'],openBalanceAmount=doc['correspondence']['openBalanceAmount'],netMoneyOut=doc['correspondence']['netMoneyOut'],
                       fullName=doc['correspondence']['fullName'],
                       closingDate=doc['correspondence']['closingDate'],
                       catchUpLimit=doc['correspondence']['catchUpLimit'],
                       netMoneyIn=doc['correspondence']['netMoneyIn'],
                       yearlyRetrun=doc['correspondence']['yearlyRetrun'],
                       quaterlyRetrun=doc['correspondence']['quaterlyRetrun'],
                       InversmentGainorLoss=doc['correspondence']['InversmentGainorLoss'],
                       openBalanceDate=doc['correspondence']['openBalanceDate'],
                       increaseFAmount=doc['correspondence']['increaseFAmount'],
                       closingBalance=doc['correspondence']['closingBalance'])
    elif templateID == "acme_statement_6789":
        document.merge(productName=doc['correspondence']['productName'],
                       CLB=doc['correspondence']['CLB'],
                       IGA=doc['correspondence']['IGA'],
                       accountName=doc['correspondence']['accountName'],
                       lastName=doc['correspondence']['lastName'],
                       OPB=doc['correspondence']['OPB'],
                       statementPeriod=doc['correspondence']['statementPeriod'],
                       QPR=doc['correspondence']['QPR'],
                       agentName=doc['correspondence']['agentName'],
                       APR=doc['correspondence']['APR'],
                       policyPeriod=doc['correspondence']['policyPeriod'],
                       years=doc['correspondence']['years'],
                       current=doc['correspondence']['current'],
                        pstart = doc['correspondence']['pstart'],
                        pend = doc['correspondence']['pend'],
                       firstName=doc['correspondence']['firstName'])
    elif templateID == "citi_statement_6789":
        document.merge(productName=doc['correspondence']['productName'],
                       CLB=doc['correspondence']['CLB'],
                       IGA=doc['correspondence']['IGA'],
                       accountName=doc['correspondence']['accountName'],
                       lastName=doc['correspondence']['lastName'],
                       OPB=doc['correspondence']['OPB'],
                       statementPeriod=doc['correspondence']['statementPeriod'],
                       QPR=doc['correspondence']['QPR'],
                       agentName=doc['correspondence']['agentName'],
                       APR=doc['correspondence']['APR'],
                       policyPeriod=doc['correspondence']['policyPeriod'],
                       firstName=doc['correspondence']['firstName'])
    elif templateID == "SS_CL_LetterTemplate_6798":
        document.merge(balanceDate=doc['correspondence']['balanceDate'],state=doc['correspondence']['state'],addressLine1=doc['correspondence']['addressLine1'],fullName=doc['correspondence']['fullName'],balanceAmount=doc['correspondence']['balanceAmount'],expiryDate=doc['correspondence']['expiryDate'],accountNumber=doc['correspondence']['accountNumber'],operatorName=doc['correspondence']['operatorName'],addressLine4=doc['correspondence']['addressLine4'],shortName=doc['correspondence']['shortName'],addressLine3=doc['correspondence']['addressLine3'],currentDate=doc['correspondence']['currentDate'],addressLine2=doc['correspondence']['addressLine2'],addressLine5=doc['correspondence']['addressLine5'])
    else:
        print("error in template mapping. Please complete the mapping ")
    return document

customerID =""

def sendMessage(urlinput,to_whatsapp_number,message):
    
    # client credentials are read from TWILIO_ACCOUNT_SID and AUTH_TOKEN
    client = Client()

    # this is the Twilio sandbox testing number
    from_whatsapp_number = 'whatsapp:+14155238886'
    # replace this number with your own WhatsApp Messaging number
    #to_whatsapp_number = 'whatsapp:+917708605798'

    client.messages.create(body=message,
                           from_=from_whatsapp_number,
                           to=to_whatsapp_number)

    message = client.messages \
        .create(
        media_url=urlinput,
        from_=from_whatsapp_number,
        to=to_whatsapp_number
    )

def dataPopulationintoTemplate(document,doc,templateName,docxoutFilename):

    document = executeMappingRule(document, doc, templateName)
    print("execute mapping after", docxoutFilename)
    document.write(docxoutFilename)
    print("write document",docxoutFilename)
    return (document)

def dump_response(response):
    print("Upload response:")
    for key in sorted(response.keys()):
        print("  %s: %s" % (key, response[key]))

# def generateDigitalPDF(inputXML,properites):
#     #with open(triggerFile) as input_file:
#     print(inputXML)
#     try:
#         doc = xmltodict.parse(inputXML)
#         print("xmlFileNameTag" , xmlFileNameTag)
#         templateName = (doc['correspondence'][properites['properties']['xmlFileNameTag']])
#         #customerName = (doc['correspondence']["firstName"])
#         outFilename = templateName
#         #+ customerName
#         outFilename = append_timestamp(outFilename)
#         print("Template Path:",properites['properties']['digitaltemplatedir'] + templateName + properites['properties']['templateExtn'])
#         digitaltemplateFilePath = properites['properties']['digitaltemplatedir'] + templateName + properites['properties']['templateExtn']
#         document = MailMerge(digitaltemplateFilePath)
#         outFilename = append_timestamp(outFilename)
#         print(outFilename + "......")
#         docxoutFilename = properites['properties']['docxoutdirdigitalchannel'] + outFilename + properites['properties']['dotDocx']
#         document = dataPopulationintoTemplate(document, doc, templateName ,docxoutFilename)
#         document.close()
#         convert(docxoutFilename, properites['properties']['pdfoutdir'] + outFilename + properites['properties']['dotPdf'])
#         print("PDF Generation  Done ......" + append_timestamp("PDF"))
#         PDF_G = append_timestamp("PDF")
#         print("PDF_G" ,PDF_G, "PDF Output Location " , properites['properties']['pdfoutdir'] + outFilename + properites['properties']['dotPdf'])
#         document.close()
#     except OSError:
#         document.close()
#         print("The Trigger  Failed:- " )
#     return(properites['properties']['pdfoutdir'] + outFilename + properites['properties']['dotPdf'] ,outFilename + properites['properties']['dotPdf'] )

def generateDigitalPDF(inputXML,properites):
    try:
        doc = xmltodict.parse(inputXML)
        print("xmlFileNameTag", xmlFileNameTag)
        templateName = (doc['correspondence'][properites['properties']['xmlFileNameTag']])
        #customerName = (doc['correspondence']["firstName"])
        outFilename = templateName
        outFilename = append_timestamp(outFilename)
        print("Template Path:",
              properites['properties']['digitaltemplatedir'] + templateName + properites['properties']['templateExtn'])
        digitaltemplateFilePath = properites['properties']['digitaltemplatedir'] + templateName + \
                                  properites['properties']['templateExtn']
                                  
        word2PDF(digitaltemplateFilePath, properites['properties']['pdfoutdir'] , properites['properties']['LIBRE_OFFICE'])
        document = MailMerge(digitaltemplateFilePath)
        outFilename = append_timestamp(outFilename)
        print(outFilename + "......")
        docxoutFilename = properites['properties']['docxoutdirdigitalchannel'] + outFilename + properites['properties'][
            'dotDocx']
        document = dataPopulationintoTemplate(document, doc, templateName, docxoutFilename)
        docxoutFilenameV = properites['properties']['docxoutdirdigitalchannel'] + "/" + outFilename + properites['properties']['dotDocx']
        document.write(docxoutFilenameV)
        document.close()
        #convert(docxoutFilename,properites['properties']['pdfoutdir'] + outFilename + properites['properties']['dotPdf'])
                
        word2PDF(docxoutFilenameV, properites['properties']['pdfoutdir'] , properites['properties']['LIBRE_OFFICE'])
        print("V3Generation Done  ......" ,properites['properties']['pdfoutdir'] + "docx"+outFilename+properites['properties']['dotPdf'])
        print("PDF Generation  Done ......" + append_timestamp("PDF"))
        # HTML_G = append_timestamp("HTML")
        pdfFilePath = properites['properties']['pdfoutdir'] + outFilename + properites['properties']['dotPdf']
        # htmlFilepath=properites['properties']['htmloutdir'] +outFilename+properites['properties']['dotHtml']
        # output = pypandoc.convert_file(docxoutFilename, 'html5', outputfile=htmlFilepath)
        # print("HTMLG", HTML_G, "HTML Output Location ",htmlFilepath)
        #document.close()
    except OSError:
        document.close()
        print("The Trigger  Failed:- ")

    return (pdfFilePath, outFilename + properites['properties']['dotPdf'])

def generateDigitalHTML(inputXML,properites):

  try:
      doc = xmltodict.parse(inputXML)
      print("xmlFileNameTag", xmlFileNameTag)
      templateName = (doc['correspondence'][properites['properties']['xmlFileNameTag']])
      #customerName = (doc['correspondence']["firstName"])
      outFilename = templateName
      outFilename = append_timestamp(outFilename)
      print("Template Path:",
            properites['properties']['digitaltemplatedir'] + templateName + properites['properties']['templateExtn'])
      digitaltemplateFilePath = properites['properties']['digitaltemplatedir'] + templateName + \
                                properites['properties']['templateExtn']
      document = MailMerge(digitaltemplateFilePath)
      outFilename = append_timestamp(outFilename)
      print(outFilename + "......")
      docxoutFilename = properites['properties']['docxoutdirdigitalchannel'] + outFilename + properites['properties'][
          'dotDocx']
      document = dataPopulationintoTemplate(document, doc, templateName, docxoutFilename)
      document.close()
      convert(docxoutFilename,
              properites['properties']['pdfoutdir'] + outFilename + properites['properties']['dotPdf'])
      #print("PDF Generation  Done ......" + append_timestamp("PDF"))
      HTML_G = append_timestamp("HTML")
      pdfFilePath = properites['properties']['pdfoutdir'] + outFilename + properites['properties']['dotPdf']
      htmlFilepath=properites['properties']['htmloutdir'] +outFilename+properites['properties']['dotHtml']
      output = pypandoc.convert_file(docxoutFilename, 'html5', outputfile=htmlFilepath)
      print("HTMLG", HTML_G, "HTML Output Location ",htmlFilepath)
      document.close()
  except OSError:
      document.close()
      print("The Trigger  Failed:- ")
  return (htmlFilepath, outFilename + properites['properties']['dotHtml'])


def generateVideoCommunication(inputXML,properites):
    #with open(triggerFile) as input_file:
    startTime = append_timestamp("Start")
    print("Video Generation Start ......" + startTime)
    #print(inputXML)
    try:
        doc = xmltodict.parse(inputXML)
        print("xmlFileNameTag" , xmlFileNameTag)
        templateName = (doc['correspondence'][properites['properties']['xmlFileNameTag']])
        outFilename = templateName 
        outFilename = append_timestamp(outFilename)
        audiotemplateFilePath = properites['properties']['audiotemplatedir'] + templateName + properites['properties']['templateExtn']
        documentA = MailMerge(audiotemplateFilePath)
        documentA = executeMappingRule(documentA, doc, templateName)
        docxoutFilenameA = properites['properties']['docxoutdirAudio'] + outFilename + dotDocx
        documentA.write(docxoutFilenameA)
        documentA.close()

        _TEXT = docx2txt.process(docxoutFilenameA)
        # print(_TEXT)
        language = 'en'
        myobj = gTTS(text=_TEXT, lang=language, slow=False)
        myobj.save(properites['properties']['audiooutdir'] + outFilename + properites['properties']['audioExtn'])
        print("Audio Generation Done  ......" + append_timestamp("Audio"))
        AUDIO_G = append_timestamp("AUDIO")

        videotemplateFilePath = properites['properties']['videotemplatedir'] + templateName + properites['properties']['templateExtn']
        print(videotemplateFilePath)
        print("V1Generation Done  ......")
        documentV = MailMerge(videotemplateFilePath)
        documentV = executeMappingRule(documentV, doc, templateName)
        docxoutFilenameV = properites['properties']['docxoutdirdigitalchannel'] + "/docx" + outFilename + properites['properties']['dotDocx']
        documentV.write(docxoutFilenameV)
        documentV.close()
        print("V2Generation Done  ......")
        convert(docxoutFilenameV, properites['properties']['pdfoutdir'] + "photo/" + outFilename + properites['properties']['dotPdf'])
        print("V3Generation Done  ......")
        
        os.mkdir(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename )

        input_file = properites['properties']['pdfoutdir'] +  "photo/" + outFilename + properites['properties']['dotPdf']
        photo_file = "D:/ezComms_Runtime/images/" + "common" + "_photo.jpg"
        if os.path.exists("D:/ezComms_Runtime/images/" + doc['correspondence']['firstName'] + "_photo.jpg"):
            photo_file = "D:/ezComms_Runtime/images/" + doc['correspondence']['firstName'] + "_photo.jpg"

        # define the position (upper-right corner)
        # image_rectangle = fitz.Rect(450,20,550,120)s

        image_rectangle = fitz.Rect(50, 70, 110, 130)

        # retrieve the first page of the PDF
        file_handle = fitz.open(input_file)
        i = 0
        for i in range(len(file_handle)):
            first_page = file_handle[i]
            first_page.insertImage(image_rectangle, filename=photo_file)
            i = i + 1

        # add the image

        file_handle.save(properites['properties']['pdfoutdir'] +  outFilename + properites['properties']['dotPdf'])


        pages = convert_from_path(properites['properties']['pdfoutdir'] + outFilename + properites['properties']['dotPdf'], 200)
        pageCount = 0
        for page in pages:
            pageCount = pageCount + 1
            page.save(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename + "/" + str(pageCount) + ".jpg", 'JPEG')
            pageCount = pageCount + 1
            page.save(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename + "/" + str(pageCount) + ".jpg", 'JPEG')

        fps = 0.5
        image_folder = properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename
        image_files = [image_folder + '/' + img for img in sorted(os.listdir(image_folder)) if img.endswith(".jpg")]
        image_files = natsort.natsorted(image_files, reverse=False)
        clip = moviepy.video.io.ImageSequenceClip.ImageSequenceClip(image_files, fps=fps)
        clip.write_videofile(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename + properites['properties']['videoExtn'])
        videoclip = VideoFileClip(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename + properites['properties']['videoExtn'])
        audioclip = AudioFileClip(properites['properties']['audiooutdir'] + outFilename + properites['properties']['audioExtn'])
        new_audioclip = CompositeAudioClip([audioclip])
        videoclip.audio = new_audioclip
        videoclip.write_videofile(properites['properties']['videooutdir'] + outFilename + properites['properties']['videoExtn'], audio_codec="aac")
        print("Start Time.........."  + startTime)
        print("Video Generation Done ......" + append_timestamp("Video"))
        documentA.close()
        documentV.close()
    except OSError:
        documentA.close()
        print("The Trigger  Failed:- " )
    return(properites['properties']['videooutdir'] + outFilename + properites['properties']['videoExtn'] ,outFilename + properites['properties']['videoExtn'] )


def sendsVideoCommunication(inputXML,properites):
    doc = xmltodict.parse(inputXML)
    clip = mp.VideoFileClip(properites['properties']['videooutdir']+doc['correspondence']['outVideoFilename']+properites['properties']['videoExtn'])
    clip_resized = clip.resize(height=200)  # make the height 360px ( According to moviePy documenation The width is then computed so that the width/height ratio is conserved.)
    clip_resized.write_videofile(properites['properties']['videooutdir'] + "whatsup/" + doc['correspondence']['outVideoFilename']+properites['properties']['videoExtn'],audio_codec="aac")
    VA_G = append_timestamp("VideoAudio")
    filePath = properites['properties']['videooutdir'] + "whatsup/" + doc['correspondence']['outVideoFilename']+properites['properties']['videoExtn']
    DEFAULT_TAG = "Try Kannan"
    print("--- Upload a local file")
    response = upload(filePath, resource_type= "video")
    dump_response(response)
    path=response["url"]
    print("",)
    message = "Welcome " + doc['correspondence']['firstName'] + " to Acke Retirement, This is your Video Statement for your retirement benefit::"
    to_whatsapp_number= doc['correspondence']['to_whatsapp_number']
    sendMessage(path,to_whatsapp_number,message)
    return( "Video Correspondance Sent to:"+ to_whatsapp_number )

# def coverPDF2Video(pdffile,properites):
#
#     outfile = append_timestamp("outFilename")
#     os.mkdir(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outfile
#     pages = convert_from_path(pdffile,200)
#     pageCount = 0
#     for page in pages:
#         pageCount = pageCount + 1
#         page.save(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename + "/" + str(
#             pageCount) + ".jpg", 'JPEG')
#         pageCount = pageCount + 1
#         page.save(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename + "/" + str(
#             pageCount) + ".jpg", 'JPEG')
#
#     fps = 0.5
#     image_folder = properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename
#     image_files = [image_folder + '/' + img for img in sorted(os.listdir(image_folder)) if img.endswith(".jpg")]
#     image_files = natsort.natsorted(image_files, reverse=False)
#     clip = moviepy.video.io.ImageSequenceClip.ImageSequenceClip(image_files, fps=fps)
#     clip.write_videofile(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename +
#                          properites['properties']['videoExtn'])
#     videoclip = VideoFileClip(properites['properties']['docxoutdirdigitalchannel'] + "videoprocessing/" + outFilename +
#                               properites['properties']['videoExtn'])
#     audioclip = AudioFileClip(
#         properites['properties']['audiooutdir'] + outFilename + properites['properties']['audioExtn'])
#     new_audioclip = CompositeAudioClip([audioclip])


# inputXML = "<correspondence><companyName>TCS</companyName>" \
# "<templateID>citi_statement_6789</templateID>" \
# "<customerID>ID123</customerID>" \
# "<to_whatsapp_number>whatsapp:+919789260241</to_whatsapp_number>" \
# "<accountName>D5467</accountName>" \
# "<productName>AKME POWER</productName>" \
# "<firstName>Faraday</firstName>" \
# "<lastName>Madasamy</lastName>" \
# "<agentName>Tom Smith</agentName>" \
# "<policyPeriod>2005-2035</policyPeriod>" \
# "<statementPeriod>June 2020</statementPeriod>" \
# "<statementDate>June 2020</statementDate>" \
# "<APR>21.3</APR>" \
# "<QPR>12.2</QPR>" \
# "<OPB>37.4 M</OPB>" \
# "<CLB>44.9 M</CLB>" \
# "<IGA>$900k in 30 days</IGA>" \
# "</correspondence>"

# properites=loadconfig()
# generateVideoCommunication(inputXML,properites)

# exit(1)

from flask import Flask, jsonify, abort, make_response, request, render_template
from flask import send_file
app = Flask(__name__)

@app.route('/eComms/pdfGen',methods=['POST'])
def eCommsPDF():
    #return ("SSS Hello World" + str(request.data))
    #print(str(request.data).replace('\n', '').replace('\r', '').replace('b/', ''))
    properites=loadconfig()
    print(request.data.decode())
    filepath , outFileName = generateDigitalPDF(str(request.data.decode()),properites)
    return(send_file(filepath , outFileName))

@app.route('/eComms/htmlGen',methods=['POST'])
def eCommsHTML():
    #return ("SSS Hello World" + str(request.data))
    properites = loadconfig()
    filepath , outFileName = generateDigitalHTML(str(request.data.decode()),properites)
    return(filepath)

@app.route('/eComms/videoGen',methods=['POST'])
def eCommsVideo():
    #return ("SSS Hello World" + str(request.data))
    properites = loadconfig()
    filepath , outFileName = generateVideoCommunication(str(request.data.decode()),properites)
    return(filepath)

@app.route('/eComms/sendVideo',methods=['POST'])
def eCommsSendComms():
    #return ("SSS Hello World" + str(request.data))
    properites = loadconfig()
    outstr = sendsVideoCommunication(str(request.data.decode()),properites)
    return(outstr)


if __name__ == "__main__":
    app.run(port=7000)

print("Completed")
