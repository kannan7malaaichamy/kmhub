package com.kemper.pp.IDOC;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


public class App 
{
    public static void main( String[] args )
    {
    	
    	Map<String, String> idocnamevaluexmltagmap = new HashMap<String, String>();
    	App app = new App();
    	Map<String, String> namevaluemmap = new HashMap<String, String>();
    	Map<String, Map<String,String>> policieswisenamevaluemmap = new HashMap<String, Map<String,String>>();
    	String sbxml = new String();
    	try
        {
    		idocnamevaluexmltagmap = App.loadstartendxmlTagsConfig();
    		policieswisenamevaluemmap = App.parseIDocFile(idocnamevaluexmltagmap);
    		sbxml  = App.generateXML(policieswisenamevaluemmap);
    		System.out.println("Output"+sbxml);
    	}
    	catch (Exception e) 
        {
        	System.out.println("Exception");
        	e.printStackTrace();
        }
    	
    	
    }
    
    static void writeOutput(String str,String filename) {
        try {
            FileOutputStream fos = new FileOutputStream("C:\\Kemper\\outputxml\\" + filename + ".xml");
            Writer out = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
            out.write(str);
            out.close();
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    static class Token 
    {
        public final int start, end;
        public final String xmlTag;

        public Token(int start, int end, String xmlTag) {
            this.start = start;
            this.end = end;
            this.xmlTag = xmlTag;
        }
    }  

    public static Map<String, String>  loadstartendxmlTagsConfig() throws  Exception
	{
    	
    	String line = "";  
    	String splitBy = ",";  
    	Map<String, String> idocnamevaluexmltagmap = new HashMap<String, String>();
    	try   
    	{  
    		//parsing a CSV file into BufferedReader class constructor  
	    	BufferedReader br = new BufferedReader(new FileReader("C:\\Kemper\\idocnamevaluexmltag.csv"));  
	    	int count=1;
	    	
	    	while ((line = br.readLine()) != null)   //returns a Boolean value  
	    	{  	
	    		if (count == 1)	{count=count+1;	continue;}
	    		String[] idocnamevaluexmltag = line.split(splitBy);    // use comma as separator  
	    		idocnamevaluexmltagmap.put(idocnamevaluexmltag[2], idocnamevaluexmltag[0]+";"+ idocnamevaluexmltag[1]);
	    		count = count + 1;
	    	}  
    	}   
    	catch (IOException e)   
    	{  
    		e.printStackTrace();  
    	}  
    	
    	return idocnamevaluexmltagmap;
	}


    public static Map<String, Map<String,String>>  parseIDocFile(Map<String, String> idocnamevaluexmltagmap) throws  Exception
   	{
    	System.out.println("parseIDocFile"+idocnamevaluexmltagmap);
    	Map<String, String> namevaluemmap = new HashMap<String, String>();
    	Map<String, Map<String,String>> policieswisenamevaluemmap = new HashMap<String, Map<String,String>>();
    	try
        {
    		
    		
    		List<Token> tokens = new ArrayList<>();

        	for (Map.Entry<String,String> entry : idocnamevaluexmltagmap.entrySet())
        	{
        		String[] startend = entry.getValue().split(";");
        		int start = Integer.parseInt(startend[0]);
        		int end = Integer.parseInt(startend[1]);
        		tokens.add(new Token(start, end,entry.getKey()));
        	}
        	
        	String line = "";
	    	BufferedReader br = new BufferedReader(new FileReader("C:\\\\Kemper\\\\testADMI"));  
	    	String policynumber="";
        	while ((line = br.readLine()) != null)   //returns a Boolean value  
	    	{  	
        		System.out.println("parseIDocFile line"+ line);
        		policynumber="";
        		namevaluemmap = new HashMap<String, String>();
	    		for (Token token : tokens) 
	        	{
	        		String splitter = line.substring(token.start , token.end );
	        		if (token.xmlTag.equalsIgnoreCase("policyNumber"))
	        		{
	        			policynumber=splitter;
	        		}
	                namevaluemmap.put(token.xmlTag, splitter.trim());
	        	}
	    		policieswisenamevaluemmap.put(policynumber, namevaluemmap);
	    	}
	    } 
        catch (Exception e) 
        {
        	System.out.println("Exception");
        	e.printStackTrace();
        }
    	return policieswisenamevaluemmap;
   	}

    
    public static String  generateXML(Map<String, Map<String,String>> policieswisenamevaluemmap ) throws  Exception
   	{
    	System.out.println(policieswisenamevaluemmap);
    	StringBuilder sbxml = new StringBuilder();	
    	try
        {
    		for (Map.Entry<String,Map<String,String>> entry : policieswisenamevaluemmap.entrySet())
    		{
    			sbxml = new StringBuilder();	
    			for (Map.Entry<String,String> polentry : entry.getValue().entrySet())
        		{
    				sbxml.append("<"+polentry.getKey()+ ">" + polentry.getValue() + "</" + polentry.getKey() + ">");
        		}
    			System.out.println("Policy"+entry.getKey());
    			System.out.println("xml"+sbxml);
    			writeOutput(sbxml.toString(),entry.getKey().toString()) ;
    		}
        } 
        catch (Exception e) 
        {
        	System.out.println("Exception");
        	e.printStackTrace();
        }
    	return sbxml.toString();
   	}


}
    
    
