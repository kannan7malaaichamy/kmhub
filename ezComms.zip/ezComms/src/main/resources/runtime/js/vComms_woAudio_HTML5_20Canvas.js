(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"vComms_woAudio_HTML5_20Canvas_atlas_1", frames: [[0,0,1920,1080],[0,1082,1920,1080],[1922,0,737,1080],[1922,1082,569,142]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Background = function() {
	this.initialize(ss["vComms_woAudio_HTML5_20Canvas_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.checkingaccountsbannerjpgimagewidth1024height576 = function() {
	this.initialize(ss["vComms_woAudio_HTML5_20Canvas_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Layer1 = function() {
	this.initialize(ss["vComms_woAudio_HTML5_20Canvas_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.usblogo_white = function() {
	this.initialize(ss["vComms_woAudio_HTML5_20Canvas_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.SummOpt3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text("FHA Loan", "28px 'Roboto'", "#FFFFFF");
	this.text.lineHeight = 36;
	this.text.lineWidth = 308;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.SummOpt3, new cjs.Rectangle(0,0,312.2,37.6), null);


(lib.SummOpt2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text("Credit Card", "28px 'Roboto'", "#FFFFFF");
	this.text.lineHeight = 36;
	this.text.lineWidth = 308;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.SummOpt2, new cjs.Rectangle(0,0,312.2,37.6), null);


(lib.SummOpt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text("Gold Checking Package", "28px 'Roboto'", "#FFFFFF");
	this.text.lineHeight = 36;
	this.text.lineWidth = 308;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.SummOpt1, new cjs.Rectangle(0,0,312.2,37.6), null);


(lib.StatePeriodAns = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Jan 22 to Mar 22", "28px 'Roboto'", "#FFFFFF");
	this.text.lineHeight = 36;
	this.text.lineWidth = 235;
	this.text.parent = this;
	this.text.setTransform(-3.7,-7.65);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StatePeriodAns, new cjs.Rectangle(-5.7,-9.6,238.89999999999998,37.6), null);


(lib.StatePeriod = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Statement Period", "28px 'Roboto'", "#00B0F0");
	this.text.lineHeight = 36;
	this.text.lineWidth = 235;
	this.text.parent = this;
	this.text.setTransform(-0.35,-7.45);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StatePeriod, new cjs.Rectangle(-2.3,-9.4,238.9,37.6), null);


(lib.HiJohn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Hi John", "40px 'Roboto'", "#FFFFFF");
	this.text.lineHeight = 50;
	this.text.lineWidth = 235;
	this.text.parent = this;
	this.text.setTransform(-1.9,-9.95);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HiJohn, new cjs.Rectangle(-3.9,-11.9,238.9,52), null);


(lib.CustTypeAns = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Affluent", "28px 'Roboto'", "#FFFFFF");
	this.text.lineHeight = 36;
	this.text.lineWidth = 235;
	this.text.parent = this;
	this.text.setTransform(-1.1,-6.7);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CustTypeAns, new cjs.Rectangle(-3.1,-8.7,238.9,37.599999999999994), null);


(lib.custType = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Customer Type", "28px 'Roboto'", "#00B0F0");
	this.text.lineHeight = 36;
	this.text.lineWidth = 235;
	this.text.parent = this;
	this.text.setTransform(-1.25,-6.9);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.custType, new cjs.Rectangle(-3.2,-8.9,238.89999999999998,37.6), null);


(lib.CustIdAns = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("XXXXX93", "28px 'Roboto'", "#FFFFFF");
	this.text.lineHeight = 36;
	this.text.lineWidth = 235;
	this.text.parent = this;
	this.text.setTransform(-1.3,-6.5);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CustIdAns, new cjs.Rectangle(-3.3,-8.5,238.9,37.6), null);


(lib.CustID = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Customer ID", "28px 'Roboto'", "#00B0F0");
	this.text.lineHeight = 36;
	this.text.lineWidth = 235;
	this.text.parent = this;
	this.text.setTransform(-1.3,-6.9);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CustID, new cjs.Rectangle(-3.3,-8.9,238.9,37.6), null);


(lib.circBanner = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Get ready for\nspring with offers\nupto $400", "40px 'Roboto Medium'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 63;
	this.text.lineWidth = 337;
	this.text.parent = this;
	this.text.setTransform(230.7,97.1);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C4113B").s().p("A3dXeQpvpuAAtwQAAtvJvpuQJupvNvAAQNwAAJvJvQJuJuAANvQAANwpuJuQpvJvtwAAQtvAApupvg");
	this.shape.setTransform(212.5,212.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circBanner, new cjs.Rectangle(0,0,425,425), null);


(lib.blackBox = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EiV/hUXMEr/AAAMAAACovMkr/AAAg");
	this.shape.setTransform(960,540);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("EiV/BUYMAAAiovMEr/AAAMAAACovg");
	this.shape_1.setTransform(960,540);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blackBox, new cjs.Rectangle(-1,-1,1922,1082), null);


(lib.AccSummary = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.text = new cjs.Text("Account Summary", "28px 'Roboto'", "#00B0F0");
	this.text.lineHeight = 36;
	this.text.lineWidth = 246;
	this.text.parent = this;
	this.text.setTransform(-1.6,-6.85);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.AccSummary, new cjs.Rectangle(-3.6,-8.8,250.4,37.6), null);


// stage content:
(lib.vComms_woAudio_HTML5Canvas = function(mode,startPosition,loop,reversed) {
this.initialize(mode,startPosition,loop,{});

	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_18
	this.instance = new lib.blackBox();
	this.instance.setTransform(960,540,1,1,0,0,0,960,540);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},17).wait(357));

	// usb_logo_white
	this.instance_1 = new lib.usblogo_white();
	this.instance_1.setTransform(1089,36);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(374));

	// Layer_5
	this.instance_2 = new lib.circBanner();
	this.instance_2.setTransform(-44.55,1164.95,0.1498,0.1498,0,0,0,0,424.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(98).to({_off:false},0).to({scaleX:1,scaleY:1,y:1164.85},5).wait(271));

	// Layer_3
	this.instance_3 = new lib.SummOpt3();
	this.instance_3.setTransform(2108.45,823.55,1,1,0,0,0,156.1,18.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(200).to({_off:false},0).wait(1).to({x:2084.45},0).wait(1).to({x:2060.45},0).wait(1).to({x:2036.45},0).wait(1).to({x:2012.45},0).wait(1).to({x:1988.45},0).wait(1).to({x:1964.45},0).wait(1).to({x:1940.45},0).wait(1).to({x:1916.45},0).wait(1).to({x:1892.5},0).wait(1).to({x:1868.5},0).wait(1).to({x:1844.5},0).wait(1).to({x:1820.5},0).wait(1).to({x:1796.5},0).wait(1).to({x:1772.5},0).wait(1).to({x:1748.5},0).wait(1).to({x:1724.5},0).wait(1).to({x:1700.5},0).wait(1).to({x:1676.55},0).wait(156));

	// Layer_2
	this.instance_4 = new lib.SummOpt2();
	this.instance_4.setTransform(2107.95,765.55,1,1,0,0,0,156.1,18.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(192).to({_off:false},0).wait(1).to({x:2083.95},0).wait(1).to({x:2060},0).wait(1).to({x:2036.05},0).wait(1).to({x:2012.05},0).wait(1).to({x:1988.1},0).wait(1).to({x:1964.15},0).wait(1).to({x:1940.15},0).wait(1).to({x:1916.2},0).wait(1).to({x:1892.25},0).wait(1).to({x:1868.25},0).wait(1).to({x:1844.3},0).wait(1).to({x:1820.35},0).wait(1).to({x:1796.35},0).wait(1).to({x:1772.4},0).wait(1).to({x:1748.45},0).wait(1).to({x:1724.45},0).wait(1).to({x:1700.5},0).wait(1).to({x:1676.55},0).wait(164));

	// Layer_4
	this.instance_5 = new lib.SummOpt1();
	this.instance_5.setTransform(2107.95,707.95,1,1,0,0,0,156.1,18.8);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(183).to({_off:false},0).wait(1).to({x:2083.95},0).wait(1).to({x:2060},0).wait(1).to({x:2036.05},0).wait(1).to({x:2012.05},0).wait(1).to({x:1988.1},0).wait(1).to({x:1964.15},0).wait(1).to({x:1940.15},0).wait(1).to({x:1916.2},0).wait(1).to({x:1892.25},0).wait(1).to({x:1868.25},0).wait(1).to({x:1844.3},0).wait(1).to({x:1820.35},0).wait(1).to({x:1796.35},0).wait(1).to({x:1772.4},0).wait(1).to({x:1748.45},0).wait(1).to({x:1724.45},0).wait(1).to({x:1700.5},0).wait(1).to({x:1676.55},0).wait(173));

	// Account_Summary
	this.instance_6 = new lib.AccSummary();
	this.instance_6.setTransform(1350,710.5,1,1,0,0,0,118,12.5);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(183).to({_off:false},0).wait(191));

	// Jan_22_to_Mar_22
	this.instance_7 = new lib.StatePeriodAns();
	this.instance_7.setTransform(1640.5,635,1,1,0,0,0,112.5,10);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(183).to({_off:false},0).wait(191));

	// Statement_Period
	this.instance_8 = new lib.StatePeriod();
	this.instance_8.setTransform(1344.5,635,1,1,0,0,0,113.5,10);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(183).to({_off:false},0).wait(191));

	// Affluent
	this.instance_9 = new lib.CustTypeAns();
	this.instance_9.setTransform(2228.4,555,1,1,0,0,0,52,10);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(62).to({_off:false},0).wait(1).to({regX:116.4,regY:10.1,x:2254.6,y:555.1},0).wait(1).to({x:2216.4},0).wait(1).to({x:2178.25},0).wait(1).to({x:2140.05},0).wait(1).to({x:2101.9},0).wait(1).to({x:2063.7},0).wait(1).to({x:2025.5},0).wait(1).to({x:1987.35},0).wait(1).to({x:1949.15},0).wait(1).to({x:1911},0).wait(1).to({x:1872.8},0).wait(1).to({x:1834.6},0).wait(1).to({x:1796.45},0).wait(1).to({x:1758.25},0).wait(1).to({x:1720.1},0).wait(1).to({x:1681.9},0).wait(1).to({x:1643.75},0).wait(295));

	// Customer_type
	this.instance_10 = new lib.custType();
	this.instance_10.setTransform(1974.4,557.5,1,1,0,0,0,94,12.5);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(62).to({_off:false},0).wait(1).to({regX:116.2,regY:9.9,x:1958.4,y:554.9},0).wait(1).to({x:1920.2},0).wait(1).to({x:1882.05},0).wait(1).to({x:1843.85},0).wait(1).to({x:1805.7},0).wait(1).to({x:1767.5},0).wait(1).to({x:1729.3},0).wait(1).to({x:1691.15},0).wait(1).to({x:1652.95},0).wait(1).to({x:1614.8},0).wait(1).to({x:1576.6},0).wait(1).to({x:1538.4},0).wait(1).to({x:1500.25},0).wait(1).to({x:1462.05},0).wait(1).to({x:1423.9},0).wait(1).to({x:1385.7},0).wait(1).to({x:1347.55},0).wait(295));

	// XXXXX93
	this.instance_11 = new lib.CustIdAns();
	this.instance_11.setTransform(2233.95,483,1,1,0,0,0,57.5,10);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(53).to({_off:false},0).wait(1).to({regX:116.1,regY:10.3,x:2256.45,y:483.3},0).wait(1).to({x:2220.4},0).wait(1).to({x:2184.35},0).wait(1).to({x:2148.3},0).wait(1).to({x:2112.25},0).wait(1).to({x:2076.2},0).wait(1).to({x:2040.1},0).wait(1).to({x:2004.05},0).wait(1).to({x:1968},0).wait(1).to({x:1931.95},0).wait(1).to({x:1895.9},0).wait(1).to({x:1859.85},0).wait(1).to({x:1823.75},0).wait(1).to({x:1787.7},0).wait(1).to({x:1751.65},0).wait(1).to({x:1715.6},0).wait(1).to({x:1679.55},0).wait(1).to({x:1643.5},0).wait(303));

	// Customer_ID
	this.instance_12 = new lib.CustID();
	this.instance_12.setTransform(1960.45,483,1,1,0,0,0,80,10);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(53).to({_off:false},0).wait(1).to({regX:116.1,regY:9.9,y:482.9},0).wait(1).to({x:1924.4},0).wait(1).to({x:1888.35},0).wait(1).to({x:1852.3},0).wait(1).to({x:1816.25},0).wait(1).to({x:1780.2},0).wait(1).to({x:1744.1},0).wait(1).to({x:1708.05},0).wait(1).to({x:1672},0).wait(1).to({x:1635.95},0).wait(1).to({x:1599.9},0).wait(1).to({x:1563.85},0).wait(1).to({x:1527.75},0).wait(1).to({x:1491.7},0).wait(1).to({x:1455.65},0).wait(1).to({x:1419.6},0).wait(1).to({x:1383.55},0).wait(1).to({x:1347.5},0).wait(303));

	// Hi_John
	this.instance_13 = new lib.HiJohn();
	this.instance_13.setTransform(1994.45,314.5,1,1,0,0,0,69,14.5);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(13).to({_off:false},0).to({x:1301,alpha:1},14).wait(347));

	// Layer_1
	this.instance_14 = new lib.Layer1();
	this.instance_14.setTransform(1183,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(374));

	// checking_accounts_banner_jpg_image_width_1024_height_576
	this.instance_15 = new lib.checkingaccountsbannerjpgimagewidth1024height576();

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(374));

	// Background
	this.instance_16 = new lib.Background();

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(374));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(915.5,539,1496.6999999999998,626);
// library properties:
lib.properties = {
	id: 'BEF087A83AB4B64EA510481B1AFC30EF',
	width: 1920,
	height: 1080,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"http://localhost:8080/getimage?imgname=vComms_woAudio_HTML5_20Canvas_atlas_1", id:"vComms_woAudio_HTML5_20Canvas_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BEF087A83AB4B64EA510481B1AFC30EF'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;