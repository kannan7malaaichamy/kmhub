package com.tcs.ezcomms.video.ezComms.controller;


import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class videoController {

	@GetMapping("/greeting")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
	@GetMapping("/generic")
	public String generic(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
	@GetMapping("/acg")
	public String greetingacg(@RequestParam(name="id", required=false, defaultValue="World") String id, Model model) {
		model.addAttribute("name", id);
		return "acg";
	}
	@RequestMapping(value = "/js", method = RequestMethod.GET)
	public ResponseEntity download(@RequestParam(name="jsname", required=false, defaultValue="World") String jsname, Model model) throws IOException {
	    String filePath = "C:\\ezComms_Runtime\\resource\\js\\" + jsname;
	    InputStream inputStream = new FileInputStream(new File(filePath));
	    InputStreamResource inputStreamResource = new InputStreamResource(inputStream);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentLength(Files.size(Paths.get(filePath)));
	    headers.add("Access-Control-Allow-Origin","*");
		headers.add("Access-Control-Allow-Methods","POST,GET,PUT");
		headers.add("Access-Control-Allow-Headers","Content-Type");
		headers.add("Cache-Control","no-cache, no-store, must-revalidate");
	    return new ResponseEntity(inputStreamResource, headers, HttpStatus.OK);
	}
	@RequestMapping(value = "/json", method = RequestMethod.GET)
	public ResponseEntity downloadjson(@RequestParam(name="json", required=false, defaultValue="World") String json, Model model) throws IOException {
		System.out.println("json" + json);
		String filePath = "C:\\ezComms_Runtime\\resource\\json\\" + json + ".json";
	    InputStream inputStream = new FileInputStream(new File(filePath));
	    InputStreamResource inputStreamResource = new InputStreamResource(inputStream);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentLength(Files.size(Paths.get(filePath)));
	    headers.add("Access-Control-Allow-Origin","*");
		headers.add("Access-Control-Allow-Methods","POST,GET,PUT");
		headers.add("Access-Control-Allow-Headers","Content-Type");
		headers.add("Cache-Control","no-cache, no-store, must-revalidate");
	    return new ResponseEntity(inputStreamResource, headers, HttpStatus.OK);
	}
	@RequestMapping(value = "/minijs", method = RequestMethod.GET)
	public ResponseEntity downloadminijs() throws IOException {
	    String filePath = "C:\\ezComms_Runtime\\resource\\js\\createjs-2015.11.26.min.js";
	    InputStream inputStream = new FileInputStream(new File(filePath));
	    InputStreamResource inputStreamResource = new InputStreamResource(inputStream);
	    HttpHeaders headers = new HttpHeaders();
	    headers.add("Access-Control-Allow-Origin","*");
		headers.add("Access-Control-Allow-Methods","POST,GET,PUT");
		headers.add("Access-Control-Allow-Headers","Content-Type");
		headers.add("Cache-Control","no-cache, no-store, must-revalidate");
	    headers.setContentLength(Files.size(Paths.get(filePath)));
	    return new ResponseEntity(inputStreamResource, headers, HttpStatus.OK);
	}
	
	
	
	@RequestMapping(value = "/getimage", method = RequestMethod.GET)
	  public void showImage(HttpServletResponse response,@RequestParam(name="imgname", required=false, defaultValue="World") String imgname, Model model) throws Exception {

	    ByteArrayOutputStream jpegOutputStream = new ByteArrayOutputStream();
	    model.addAttribute("imgname", imgname);
		
		System.out.println("inside get mage imgname" + imgname);
	    try {
	     // BufferedImage image = //CALL_OR_CREATE_YOUR_IMAGE_OBJECT;V3_HTML5 Canvas_atlas_1
	    	BufferedImage image = ImageIO.read(new File("C:\\ezComms_Runtime\\resource\\imgs\\" + imgname));
	    	ImageIO.write(image, "jpg", jpegOutputStream);
	    } catch (IllegalArgumentException e) {
	      response.sendError(HttpServletResponse.SC_NOT_FOUND);
	    }

	    byte[] imgByte = jpegOutputStream.toByteArray();

	    response.setHeader("Cache-Control", "no-store");
	    response.setHeader("Access-Control-Allow-Origin","*");
		response.setHeader("Access-Control-Allow-Methods","POST,GET,PUT");
		response.setHeader("Access-Control-Allow-Headers","Content-Type");
	    response.setHeader("Pragma", "no-cache");
	    response.setDateHeader("Expires", 0);
	    response.setContentType("image/jpg");
	    ServletOutputStream responseOutputStream = response.getOutputStream();
	    responseOutputStream.write(imgByte);
	    responseOutputStream.flush();
	    responseOutputStream.close();
	  }
	
}