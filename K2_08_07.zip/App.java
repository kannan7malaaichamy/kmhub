package com.kemper.pp.IDOC;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.apache.commons.codec.binary.Hex;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
public class App 
{
	
	
	public static byte[] substring(byte[] array, int start, int end) {
        if (end <= start)
            return null;
        int length = (end - start);
        byte[] newArray = new byte[length];
        System.arraycopy(array, start, newArray, 0, length);
        return newArray;
    }
	private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
	public static String bytesToHex(byte[] bytes) {
	    char[] hexChars = new char[bytes.length * 2];
	    for (int j = 0; j < bytes.length; j++) {
	        int v = bytes[j] & 0xFF;
	        hexChars[j * 2] = HEX_ARRAY[v >>> 4];
	        hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
	    }
	    return new String(hexChars);
	}
	 public static int hex2decimal(String s) {
         String digits = "0123456789ABCDEF";
         s = s.toUpperCase();
         int val = 0;
         for (int i = 0; i < s.length(); i++) {
             char c = s.charAt(i);
             int d = digits.indexOf(c);
             val = 16*val + d;
         }
         return val;
     }
	 
	 public static String byte2string(byte [] stringBytes) 
	 {
		 
		 	//byte [] stringBytes = App.substring(fileBytes, 17, 21);
	        
	        char singleChar;
	        String finalString="";
	        for(byte b : stringBytes) 
	        {
	          singleChar = (char) b;
	          finalString = finalString + singleChar;
	          //System.out.print(singleChar);
	        }
	        return finalString;
     }
	 public static String removeLastChar(String s) {
		    if (s == null || s.length() == 0) {
		        return s;
		    }
		    return s.substring(0, s.length()-1);
		}
	public static Map<String, byte [] >  parseIDocFileintoMap(String filename) throws  Exception
	{
		 	Map<String, byte [] > policyRecords = new HashMap<String, byte [] >();
		 	
		 	String fileName = "C:\\Kemper\\q";
	        File file = new File(fileName);

	        byte [] fileBytes = Files.readAllBytes(file.toPath());
	        
	        int recordLength=hex2decimal(bytesToHex(App.substring(fileBytes, 00, 02)));
	        System.out.println(recordLength + fileBytes.length);
	        int recordStart=00;
	        int recordEnd=recordLength;
	        int count=1;
	        while (recordEnd <= fileBytes.length)   //returns a Boolean value  
	    	{  
	        	byte [] eachPolicyBytes = App.substring(fileBytes, recordStart, recordEnd);
	        	policyRecords.put(String.valueOf(count),eachPolicyBytes);
	        	
	        	recordStart=hex2decimal(bytesToHex(App.substring(eachPolicyBytes, 00, 02)));
	        	if (recordStart < 100)
	        		break;
	        	recordEnd = recordEnd + recordStart;
	        	
	    	}
	        System.out.println(policyRecords);
//	        for (Map.Entry<String, byte []> entry : policyRecords.entrySet())
//    		{
//        		byte [] eachpolicy = entry.getValue();
//        		 System.out.println("----"+ eachpolicy.length);
//    		}
	        // System.out.print(App.substring(fileBytes, 76, 81));
	        //System.out.println(bytesToHex(App.substring(fileBytes, 20, 24)));
	        //System.out.println(hex2decimal(bytesToHex(App.substring(fileBytes, 20, 24))));
	   		return policyRecords;
	}
	    
    public static void main( String[] args ) throws IOException
    {
    	   	
    	
    	
    	Map<String, String> idocnamevaluexmltagmap = new HashMap<String, String>();
    	App app = new App();
    	Map<String, String> namevaluemmap = new HashMap<String, String>();
    	Map<String, Map<String,String>> policieswisenamevaluemmap = new HashMap<String, Map<String,String>>();
    	String sbxml = new String();
    	try
        {
    		idocnamevaluexmltagmap = App.loadstartendxmlTagsConfig();
    		policieswisenamevaluemmap = App.parseIDocFile(idocnamevaluexmltagmap);
    		sbxml  = App.generateXML(policieswisenamevaluemmap);
    		System.out.println("Output"+sbxml);
    	}
    	catch (Exception e) 
        {
        	System.out.println("Exception");
        	e.printStackTrace();
        }
    	
    	
    }
    
    static void writeOutput(String str,String filename) 
    {
        try 
        {
            FileOutputStream fos = new FileOutputStream("C:\\Kemper\\outputxml\\" + filename + ".xml");
            Writer out = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
            out.write(str);
            out.close();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
    
    static class Token 
    {
        public final int start, end;
        public final String xmlTag,fieldtype;
        public Token(int start, int end, String xmlTag,String fieldtype) 
        {
            this.start = start;
            this.end = end;
            this.xmlTag = xmlTag;
            this.fieldtype = fieldtype;
        }
    }  

    public static Map<String, String>  loadstartendxmlTagsConfig() throws  Exception
	{
    	
    	String line = "";  
    	String splitBy = ",";  
    	Map<String, String> idocnamevaluexmltagmap = new HashMap<String, String>();
    	try   
    	{  
    		//parsing a CSV file into BufferedReader class constructor  
	    	BufferedReader br = new BufferedReader(new FileReader("C:\\Kemper\\idocnamevaluexmltag.csv"));  
	    	int count=1;
	    	
	    	while ((line = br.readLine()) != null)   //returns a Boolean value  
	    	{  	
	    		if (count == 1)	{count=count+1;	continue;}
	    		String[] idocnamevaluexmltag = line.split(splitBy);    // use comma as separator  
	    		idocnamevaluexmltagmap.put(idocnamevaluexmltag[2], idocnamevaluexmltag[0]+";"+ idocnamevaluexmltag[1]+";"+ idocnamevaluexmltag[3]);
	    		count = count + 1;
	    	}  
    	}   
    	catch (IOException e)   
    	{  
    		e.printStackTrace();  
    	}  
    	
    	return idocnamevaluexmltagmap;
	}

    public static String toHex(String arg) throws UnsupportedEncodingException {
    	  return String.format("%x", new BigInteger(1, arg.getBytes("ISO-8859-1")));
    	}
    public static Map<String, Map<String,String>>  parseIDocFile(Map<String, String> idocnamevaluexmltagmap) throws  Exception
   	{
    	System.out.println("parseIDocFile"+idocnamevaluexmltagmap);
    	Map<String, String> namevaluemmap = new HashMap<String, String>();
    	Map<String, Map<String,String>> policieswisenamevaluemmap = new HashMap<String, Map<String,String>>();
    	try
        {
    		List<Token> tokens = new ArrayList<>();
        	for (Map.Entry<String,String> entry : idocnamevaluexmltagmap.entrySet())
        	{
        		String[] startend = entry.getValue().split(";");
        		int start = Integer.parseInt(startend[0]);
        		int end = Integer.parseInt(startend[1]);
        		String fieldType = startend[2];
        		tokens.add(new Token(start, end,entry.getKey(),fieldType));
        	}
        	String filename ="";
        	Map<String, byte []> policyRecords = parseIDocFileintoMap(filename);
        	
        	String line = "";
	    	String policynumber="";
        		
        	//System.out.println("parseIDocFile line.substring(1,2);"+ App.toHex(line.substring(1,2)));
        	policynumber="";
        	namevaluemmap = new HashMap<String, String>();
        	//System.out.println(bytesToHex(App.substring(fileBytes, 20, 24)));
	        //System.out.println(hex2decimal(bytesToHex(App.substring(fileBytes, 20, 24))));
        	for (Map.Entry<String, byte []> entry : policyRecords.entrySet())
    		{
        		byte [] eachpolicy = entry.getValue();
	        	for (Token token : tokens) 
		        {
	        		System.out.println("eachpolicy" + eachpolicy.length);
	        		String outValue ="empty";
	    			if (token.fieldtype.equalsIgnoreCase("STRING"))
	        		{
	    				//eachpolicy
	    				outValue=App.byte2string(App.substring(eachpolicy, token.start+3, token.end+3));
	        		}
		    		if (token.fieldtype.equalsIgnoreCase("COMP3"))
	        		{
		    			//System.out.println(bytesToHex(App.substring(eachpolicy, token.start, token.end)));
		    	        System.out.println(hex2decimal(App.removeLastChar(App.bytesToHex(App.substring(eachpolicy,token.start+3, token.end+3)))));
		    	        outValue = String.valueOf(hex2decimal(App.removeLastChar(App.bytesToHex(App.substring(eachpolicy,token.start+3, token.end+3)))));
	        		}
		    		if (token.fieldtype.equalsIgnoreCase("COMP"))
	        		{
		    			//System.out.println(bytesToHex(App.substring(eachpolicy, token.start, token.end)));
		    			outValue = String.valueOf(hex2decimal(bytesToHex(App.substring(eachpolicy, token.start+3, token.end+3))));
	        		}
		    	    namevaluemmap.put(token.xmlTag, outValue.trim());
		        }
	        	policieswisenamevaluemmap.put(entry.getKey(), namevaluemmap);
    		}
    		
	    	
	    } 
        catch (Exception e) 
        {
        	System.out.println("Exception");
        	e.printStackTrace();
        }
    	return policieswisenamevaluemmap;
   	}

    
    public static String  generateXML(Map<String, Map<String,String>> policieswisenamevaluemmap ) throws  Exception
   	{
    	System.out.println(policieswisenamevaluemmap);
    	StringBuilder sbxml = new StringBuilder();	
    	try
        {
    		for (Map.Entry<String,Map<String,String>> entry : policieswisenamevaluemmap.entrySet())
    		{
    			sbxml = new StringBuilder();	
    			for (Map.Entry<String,String> polentry : entry.getValue().entrySet())
        		{
    				sbxml.append("<"+polentry.getKey()+ ">" + polentry.getValue() + "</" + polentry.getKey() + ">");
        		}
    			System.out.println("Policy"+entry.getKey());
    			System.out.println("xml"+sbxml);
    			writeOutput(sbxml.toString(),entry.getKey().toString()) ;
    		}
        } 
        catch (Exception e) 
        {
        	System.out.println("Exception");
        	e.printStackTrace();
        }
    	return sbxml.toString();
   	}


}
    
    
