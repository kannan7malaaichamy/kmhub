package com.tcs.ecomms.eDocs.controller;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ReqPdfgen {
	private final String USER_AGENT = "Java client";
	private final String PDF_URL_EXTN = "/output/pdf-preview";
	private static HttpURLConnection con;
	
	public String sendingPostRequest(String templateID,String JsonData,eDocsParm eDocsParm)throws Exception {
		String urlInput = eDocsParm.getRestUrl()+templateID+PDF_URL_EXTN;
		URL url = new URL(urlInput);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		String op = "";
		con.setRequestMethod("POST");
		con.setRequestProperty("User-Agent", USER_AGENT);
		con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		con.setRequestProperty("Content-Type", "application/json");
		con.setDoOutput(true);
		DataOutputStream  dos = new DataOutputStream(con.getOutputStream());
		dos.writeBytes(JsonData);
        dos.flush();
        dos.close();
		try(BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(),"utf-8"))){
			StringBuffer response = new StringBuffer();
			String responseLine = null;
			while((responseLine = br.readLine()) != null) {
				response.append(responseLine.trim());
			}
			op = response.toString().split("\"")[3];
		}
		return op;
		
	}
}
