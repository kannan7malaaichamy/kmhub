package com.tcs.ecomms.eDocs.controller;

import java.io.Serializable;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class eDocsParm 
{
    
	public String pdfoutdir;
    public String xmldir;
    public String videotemplatedir;
    public String jsonoutdir;
    public String pythonScriptName;
    public String htmloutdir;
 	public String docoutdir;
 	public String docxoutdir;
    public String configdir;
    public String resourcedir;
    public String pdfoutputflag;
    public String wordoutputflag;
    public String htmloutputflag;
    public String errorPDFPath;
    public String dotDoc;
    public String dotPdf;
    public String dotDocx;
    public String dotHtml;
    public String templateExtn;
    public String audiotemplateExtn;
    public String imageFileExtn;
    public String docxoutdirdigitalchannel;
    public String videooutputflag;
    public String dotxml;
    public String audioExtn;
    public String videoExtn;
    public String processCompleteExtn;
    public String xmlFileNameTag;
    public String videoprocessingdir;
    public String triggerFile;
    public String LIBRE_OFFICE;
    public String audiotemplatedir;
    public String digitaltemplatedir;
    public String audiooutdir;
    public String videooutdir;
    public String docxoutdiraudio;
    public String pdfoutdiraudio;
    public String textoutdiraudio;
    public String grapthFolder;
    public String grapthImageExtn;
    
    public String pdfExtn;
    public String jsonExtn;
    public String restUrl;
    
    public String getPdfExtn() {
		return pdfExtn;
	}
	public void setPdfExtn(String pdfExtn) {
		this.pdfExtn = pdfExtn;
	}
	public String getJsonExtn() {
		return jsonExtn;
	}
	public void setJsonExtn(String jsonExtn) {
		this.jsonExtn = jsonExtn;
	}
	public String getRestUrl() {
		return restUrl;
	}
	public void setRestUrl(String restUrl) {
		this.restUrl = restUrl;
	}
	
    
    public String getGrapthFolder() {
		return grapthFolder;
	}
	public void setGrapthFolder(String grapthFolder) {
		this.grapthFolder = grapthFolder;
	}
	public String getGrapthImageExtn() {
		return grapthImageExtn;
	}
	public void setGrapthImageExtn(String grapthImageExtn) {
		this.grapthImageExtn = grapthImageExtn;
	}
	public String getAudiotemplateExtn() {
		return audiotemplateExtn;
	}
	public void setAudiotemplateExtn(String audiotemplateExtn) {
		this.audiotemplateExtn = audiotemplateExtn;
	}
	public String getDocxoutdiraudio() {
		return docxoutdiraudio;
	}
	public void setDocxoutdiraudio(String docxoutdiraudio) {
		this.docxoutdiraudio = docxoutdiraudio;
	}
	public String getPdfoutdiraudio() {
		return pdfoutdiraudio;
	}
	public void setPdfoutdiraudio(String pdfoutdiraudio) {
		this.pdfoutdiraudio = pdfoutdiraudio;
	}
	public String getTextoutdiraudio() {
		return textoutdiraudio;
	}
	public void setTextoutdiraudio(String textoutdiraudio) {
		this.textoutdiraudio = textoutdiraudio;
	}
	public String getDigitaltemplatedir() {
		return digitaltemplatedir;
	}
	public void setDigitaltemplatedir(String digitaltemplatedir) {
		this.digitaltemplatedir = digitaltemplatedir;
	}
	public String getAudiooutdir() {
		return audiooutdir;
	}
	public void setAudiooutdir(String audiooutdir) {
		this.audiooutdir = audiooutdir;
	}
	public String getVideooutdir() {
		return videooutdir;
	}
	public void setVideooutdir(String videooutdir) {
		this.videooutdir = videooutdir;
	}
	
	public String getAudiotemplatedir() {
		return audiotemplatedir;
	}
	public void setAudiotemplatedir(String audiotemplatedir) {
		this.audiotemplatedir = audiotemplatedir;
	}
	public String getDocxoutdirdigitalchannel() {
		return docxoutdirdigitalchannel;
	}
	public void setDocxoutdirdigitalchannel(String docxoutdirdigitalchannel) {
		this.docxoutdirdigitalchannel = docxoutdirdigitalchannel;
	}
	public String getVideooutputflag() {
		return videooutputflag;
	}
	public void setVideooutputflag(String videooutputflag) {
		this.videooutputflag = videooutputflag;
	}
	public String getDotxml() {
		return dotxml;
	}
	public void setDotxml(String dotxml) {
		this.dotxml = dotxml;
	}
	public String getAudioExtn() {
		return audioExtn;
	}
	public void setAudioExtn(String audioExtn) {
		this.audioExtn = audioExtn;
	}
	public String getVideoExtn() {
		return videoExtn;
	}
	public void setVideoExtn(String videoExtn) {
		this.videoExtn = videoExtn;
	}
	public String getProcessCompleteExtn() {
		return processCompleteExtn;
	}
	public void setProcessCompleteExtn(String processCompleteExtn) {
		this.processCompleteExtn = processCompleteExtn;
	}
	public String getXmlFileNameTag() {
		return xmlFileNameTag;
	}
	public void setXmlFileNameTag(String xmlFileNameTag) {
		this.xmlFileNameTag = xmlFileNameTag;
	}
	public String getVideoprocessingdir() {
		return videoprocessingdir;
	}
	public void setVideoprocessingdir(String videoprocessingdir) {
		this.videoprocessingdir = videoprocessingdir;
	}
	public String getTriggerFile() {
		return triggerFile;
	}
	public void setTriggerFile(String triggerFile) {
		this.triggerFile = triggerFile;
	}
	public String getLIBRE_OFFICE() {
		return LIBRE_OFFICE;
	}
	public void setLIBRE_OFFICE(String lIBRE_OFFICE) {
		LIBRE_OFFICE = lIBRE_OFFICE;
	}
	public String getXmldir() {
		return xmldir;
	}
	public void setXmldir(String xmldir) {
		this.xmldir = xmldir;
	}
	public String getJsonoutdir() {
		return jsonoutdir;
	}
	public void setJsonoutdir(String jsonoutdir) {
		this.jsonoutdir = jsonoutdir;
	}
	public String getPythonScriptName() {
		return pythonScriptName;
	}
	public void setPythonScriptName(String pythonScriptName) {
		this.pythonScriptName = pythonScriptName;
	}
	public String getVideotemplatedir() {
		return videotemplatedir;
	}
	public void setVideotemplatedir(String videotemplatedir) {
		this.videotemplatedir = videotemplatedir;
	}
	public String getErrorPDFPath() {
		return errorPDFPath;
	}
	public void setErrorPDFPath(String errorPDFPath) {
		this.errorPDFPath = errorPDFPath;
	}
	public String getResourcedir() {
		return resourcedir;
	}
	public void setResourcedir(String resourcedir) {
		this.resourcedir = resourcedir;
	}
	public String getImageFileExtn() {
		return imageFileExtn;
	}
	public void setImageFileExtn(String imageFileExtn) {
		this.imageFileExtn = imageFileExtn;
	}
	public String getDotDoc() {
		return dotDoc;
	}
	public void setDotDoc(String dotDoc) {
		this.dotDoc = dotDoc;
	}
	public String getDotPdf() {
		return dotPdf;
	}
	public void setDotPdf(String dotPdf) {
		this.dotPdf = dotPdf;
	}
	public String getDotDocx() {
		return dotDocx;
	}
	public void setDotDocx(String dotDocx) {
		this.dotDocx = dotDocx;
	}
	public String getDotHtml() {
		return dotHtml;
	}
	public void setDotHtml(String dotHtml) {
		this.dotHtml = dotHtml;
	}
	public String getTemplateExtn() {
		return templateExtn;
	}
	public void setTemplateExtn(String templateExtn) {
		this.templateExtn = templateExtn;
	}
	public String getConfigdir() {
		return configdir;
	}
	public void setConfigdir(String configdir) {
		this.configdir = configdir;
	}
	public String getPdfoutdir() 
    {
		return pdfoutdir;
	}
	public void setPdfoutdir(String pdfoutdir) {
		this.pdfoutdir = pdfoutdir;
	}
	public String getHtmloutdir() {
		return htmloutdir;
	}
	public void setHtmloutdir(String htmloutdir) {
		this.htmloutdir = htmloutdir;
	}
	public String getDocoutdir() {
		return docoutdir;
	}
	public void setDocoutdir(String docoutdir) {
		this.docoutdir = docoutdir;
	}
	public String getDocxoutdir() {
		return docxoutdir;
	}
	public void setDocxoutdir(String docxoutdir) {
		this.docxoutdir = docxoutdir;
	}
	
	public String getPdfoutputflag() {
		return pdfoutputflag;
	}
	public void setPdfoutputflag(String pdfoutputflag) {
		this.pdfoutputflag = pdfoutputflag;
	}
	public String getWordoutputflag() {
		return wordoutputflag;
	}
	public void setWordoutputflag(String wordoutputflag) {
		this.wordoutputflag = wordoutputflag;
	}
	public String getHtmloutputflag() {
		return htmloutputflag;
	}
	public void setHtmloutputflag(String htmloutputflag) {
		this.htmloutputflag = htmloutputflag;
	}
	@Override
	public String toString() {
		return "eDocsParm [pdfoutdir=" + pdfoutdir + ", xmldir=" + xmldir + ", videotemplatedir=" + videotemplatedir
				+ ", jsonoutdir=" + jsonoutdir + ", pythonScriptName=" + pythonScriptName + ", htmloutdir=" + htmloutdir
				+ ", docoutdir=" + docoutdir + ", docxoutdir=" + docxoutdir + ", configdir=" + configdir
				+ ", resourcedir=" + resourcedir + ", pdfoutputflag=" + pdfoutputflag + ", wordoutputflag="
				+ wordoutputflag + ", htmloutputflag=" + htmloutputflag + ", errorPDFPath=" + errorPDFPath + ", dotDoc="
				+ dotDoc + ", dotPdf=" + dotPdf + ", dotDocx=" + dotDocx + ", dotHtml=" + dotHtml + ", templateExtn="
				+ templateExtn + ", audiotemplateExtn=" + audiotemplateExtn + ", imageFileExtn=" + imageFileExtn
				+ ", docxoutdirdigitalchannel=" + docxoutdirdigitalchannel + ", videooutputflag=" + videooutputflag
				+ ", dotxml=" + dotxml + ", audioExtn=" + audioExtn + ", videoExtn=" + videoExtn
				+ ", processCompleteExtn=" + processCompleteExtn + ", xmlFileNameTag=" + xmlFileNameTag
				+ ", videoprocessingdir=" + videoprocessingdir + ", triggerFile=" + triggerFile + ", LIBRE_OFFICE="
				+ LIBRE_OFFICE + ", audiotemplatedir=" + audiotemplatedir + ", digitaltemplatedir=" + digitaltemplatedir
				+ ", audiooutdir=" + audiooutdir + ", videooutdir=" + videooutdir + ", docxoutdiraudio="
				+ docxoutdiraudio + ", pdfoutdiraudio=" + pdfoutdiraudio + ", textoutdiraudio=" + textoutdiraudio
				+ ", grapthFolder=" + grapthFolder + ", grapthImageExtn=" + grapthImageExtn + ", pdfExtn=" + pdfExtn
				+ ", jsonExtn=" + jsonExtn + ", restUrl=" + restUrl + "]";
	}
	

	
}