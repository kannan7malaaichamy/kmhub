package com.tcs.ecomms.eDocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EDocsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EDocsApplication.class, args);
	}

}
