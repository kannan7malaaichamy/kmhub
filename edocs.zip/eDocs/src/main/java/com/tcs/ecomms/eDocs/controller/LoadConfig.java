package com.tcs.ecomms.eDocs.controller;

import java.io.File;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.FileUtils;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

public class LoadConfig {

	
	
	public eDocsParm populateParms()
    {
		Properties props = new Properties();
		eDocsParm eDocsParm = new eDocsParm();
		try 
		{
			File propertyfile = ResourceUtils.getFile("classpath:properties.xml");
			//File is found
			System.out.println("Properties File Found : " + propertyfile.exists());
			String properyxmlstring = new String();
			properyxmlstring = FileUtils.readFileToString(propertyfile);
			System.out.println("Properties Data : " + properyxmlstring) ;
			//String xmlString =  System.IO.File.ReadAllText("c:\\ezComms_Runtime\\config\\properties.xml");
		    org.w3c.dom.Document xmldoc = processDOM(properyxmlstring);
		    xmldoc.getDocumentElement().normalize();
		      
		    String processtring = new String();
		      processtring = "tcs" ;		
		      org.w3c.dom.NodeList nodeList=xmldoc.getElementsByTagName("*");
		      
		      for (int i=0; i<nodeList.getLength(); i++) 
		      {
		      		Node elemNode = nodeList.item(i);
		      		if (elemNode.getNodeType() == Node.ELEMENT_NODE)   
		      		{  
		      			processtring = new String(elemNode.getTextContent().toString());
		      			
		      			if (elemNode.getNodeName().equalsIgnoreCase("xmldir"))
		      			{
		      					eDocsParm.setXmldir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("jsonExtn"))
		      			{
		      					eDocsParm.setXmldir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("restUrl"))
		      			{
		      					eDocsParm.setXmldir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("jsonoutdir"))
		      			{
		      				
		      				eDocsParm.setJsonoutdir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("pdfoutdir"))
		      			{
		      				System.out.println("pdfoutdir Data : " + processtring) ;
		      				eDocsParm.setPdfoutdir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("htmloutdir"))
		      			{
		      				
		      				eDocsParm.setHtmloutdir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("docoutdir"))
		      			{
		      				
		      				eDocsParm.setDocoutdir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("docxoutdirdigitalchannel"))
		      			{
		      				
		      				eDocsParm.setDocxoutdirdigitalchannel(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("docxoutdiraudio"))
		      			{
		      				
		      				eDocsParm.setDocxoutdiraudio(processtring);
		      			}
		      		
		      			if (elemNode.getNodeName().equalsIgnoreCase("digitaltemplatedir"))
		      			{
		      				
		      				eDocsParm.setDigitaltemplatedir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("audiotemplatedir"))
		      			{
		      				
		      				eDocsParm.setAudiotemplatedir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("videotemplatedir"))
		      			{
		      				
		      				eDocsParm.setVideotemplatedir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("audiooutdir"))
		      			{
		      				
		      				eDocsParm.setAudiooutdir(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("videooutdir"))
		      			{
		      				
		      				eDocsParm.setVideooutdir(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("configdir"))
		      			{
		      				
		      				eDocsParm.setConfigdir(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("resourcedir"))
		      			{
		      				
		      				eDocsParm.setResourcedir(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("pdfoutputflag"))
		      			{
		      				
		      				eDocsParm.setPdfoutputflag(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("wordoutputflag"))
		      			{
		      				
		      				eDocsParm.setWordoutputflag(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("htmloutputflag"))
		      			{
		      				
		      				eDocsParm.setHtmloutputflag(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("videooutputflag"))
		      			{
		      				
		      				eDocsParm.setVideooutputflag(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("dotDoc"))
		      			{
		      				
		      				eDocsParm.setDotDoc(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("dotPdf"))
		      			{
		      				
		      				eDocsParm.setDotPdf(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("dotDocx"))
		      			{
		      				
		      				eDocsParm.setDotDocx(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("dotHtml"))
		      			{
		      				
		      				eDocsParm.setDotHtml(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("dotxml"))
		      			{
		      				
		      				eDocsParm.setDotxml(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("templateExtn"))
		      			{
		      				
		      				eDocsParm.setTemplateExtn(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("audioExtn"))
		      			{
		      				
		      				eDocsParm.setAudioExtn(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("videoExtn"))
		      			{
		      				
		      				eDocsParm.setVideoExtn(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("processCompleteExtn"))
		      			{
		      				
		      				eDocsParm.setProcessCompleteExtn(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("imageFileExtn"))
		      			{
		      				
		      				eDocsParm.setImageFileExtn(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("xmlFileNameTag"))
		      			{
		      				
		      				eDocsParm.setXmlFileNameTag(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("videotemplatedir"))
		      			{
		      				
		      				eDocsParm.setXmlFileNameTag(processtring);
		      			}
		      			
		      			if (elemNode.getNodeName().equalsIgnoreCase("triggerFile"))
		      			{
		      				
		      				eDocsParm.setTriggerFile(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("LIBRE_OFFICE"))
		      			{
		      				
		      				eDocsParm.setLIBRE_OFFICE(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("errorPDFPath"))
		      			{
		      				
		      				eDocsParm.setErrorPDFPath(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("videoprocessingdir"))
		      			{
		      				
		      				eDocsParm.setVideoprocessingdir(processtring);
		      			}
		      			if (elemNode.getNodeName().equalsIgnoreCase("pythonScriptName"))
		      			{
		      				
		      				eDocsParm.setPythonScriptName(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("docxoutdiraudio"))
		      			{
		      				
		      				eDocsParm.setDocxoutdiraudio(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("pdfoutdiraudio"))
		      			{
		      				
		      				eDocsParm.setPdfoutdiraudio(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("textoutdiraudio"))
		      			{
		      				
		      				eDocsParm.setTextoutdiraudio(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("textoutdiraudio"))
		      			{
		      				
		      				eDocsParm.setTextoutdiraudio(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("grapthFolder"))
		      			{
		      				
		      				eDocsParm.setGrapthFolder(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("audiotemplateExtn"))
		      			{
		      				
		      				eDocsParm.setAudiotemplateExtn(processtring);
		      			}if (elemNode.getNodeName().equalsIgnoreCase("grapthImageExtn"))
		      			{
		      				
		      				eDocsParm.setGrapthImageExtn(processtring);
		      			}
		      		}
		          
		      }

		}
		catch ( Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Config  Loaded successfully" + eDocsParm.toString());
		return eDocsParm;
    }
	public org.w3c.dom.Document processDOM(String xmlString)
	  {
	  	try 
	  	{
	  		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	    	DocumentBuilder db = dbf.newDocumentBuilder();
	    	InputSource is = new InputSource(new StringReader(xmlString));
	    	org.w3c.dom.Document xmldoc = db.parse(is);
	    	return xmldoc;
	  	}
		catch(Exception e)
		{
		  	e.printStackTrace();
		}
	  	
	  	return null;
	  
	  }
	
	public boolean license() throws Exception
	{
		boolean outflag = true ; 
		try 
		{
			SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
			Date d1 = new Date();
			Date d2 = sdformat.parse("2021-01-17");
			//System.out.println("The date 1 is: " + sdformat.format(d1));
			//System.out.println("The date 2 is: " + sdformat.format(d2));
		      if(d1.compareTo(d2) > 0) 
		      {
		    	 outflag = false;
		         //System.out.println("Date 1 occurs after Date 2");
		         throw new Exception("License Expired");
		      } 
		      else if(d1.compareTo(d2) < 0) 
		      {
		    	  outflag = true;
		    	  System.out.println("Valid License");
		      } 
		      else if(d1.compareTo(d2) == 0) 
		      {
		         System.out.println("Valid License but will expire soon");
		      }
			}
			catch ( Exception e)
			{
				e.printStackTrace();	
			}
			return outflag;
	}
	
}
