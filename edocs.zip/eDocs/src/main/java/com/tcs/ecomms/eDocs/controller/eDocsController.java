package com.tcs.ecomms.eDocs.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONObject;

@RestController
@CrossOrigin(origins ="*")
@RequestMapping("/edocs")
public class eDocsController {
	@RequestMapping(value="/genpdf",method=RequestMethod.POST,consumes= {"application/xml;charset=UTF-8"},produces=MediaType.APPLICATION_PDF_VALUE)
	public byte[] generatePDF(@RequestBody String xmlString) throws Exception {
		byte[] bytecontent = new byte[2048];
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.add("Access-Control-Allow-Origin","*");
			headers.add("Access-Control-Allow-Methods","POST,GET,PUT");
			headers.add("Access-Control-Allow-Headers","Content-Type");
			headers.add("Cache-Control","no-cache, no-store, must-revalidate");
			headers.add("Pragma","no-cache");
			headers.add("Expires","0");
			JSONObject jsonObj = new JSONObject();
			String Jsondata = jsonObj.toString();
			String templateID = jsonObj.getJSONObject("correspondence").getString("templateID");
			String accountNumber = jsonObj.getJSONObject("correspondence").getString("accountnumber");
			DateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date date = new Date();
			String outputJsonname = accountNumber+ "-"+dateformat.format(date).replaceAll(" ","-").replaceAll(":","-"); 
			eDocsParm eDocsParm = new LoadConfig().populateParms();
			String Filename = eDocsParm.getJsonoutdir()+outputJsonname +eDocsParm.getJsonExtn();
			String PDfFilename = eDocsParm.getPdfoutdir()+outputJsonname+eDocsParm.getDotPdf();
			FileWriter writer = new FileWriter(Filename);
			writer.write(Jsondata);
			writer.close();
			ReqPdfgen  gen = new ReqPdfgen();
			String response = gen.sendingPostRequest(templateID,Jsondata,eDocsParm);
			bytecontent = pdfReportGen(response,PDfFilename);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return bytecontent;
	}
	
	public byte[] pdfReportGen(String urlInput, String PdfFilename ) {
		byte[] bytecontent = new byte[2048];
		try {
			URL url = new URL(urlInput);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			InputStream is = con.getInputStream();
			bytecontent = downloadFile(url.openStream(),PdfFilename);
			is.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return bytecontent;
	}
	
	public byte [] downloadFile(InputStream connectionInput,String PdfFilename) throws IOException {
		BufferedInputStream bis = new BufferedInputStream(connectionInput);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] bytecontent = new byte[2048];
		int count = 0;
		try(DataOutputStream os= new DataOutputStream(new FileOutputStream(PdfFilename))){
			while((count = bis.read(bytecontent,0,2048))!=-1) {
				baos.write(bytecontent,0,count);
				os.write(bytecontent,0,count);
			}
		}
		return baos.toByteArray();
	}
}
